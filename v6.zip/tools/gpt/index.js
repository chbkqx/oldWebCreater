import {
    $, btn
}
from "../../../module/wheel/jq.js"

import {
    Chat, getToken, getPath
}
from '../../../module/chatniosdk/chat.js';
import {
    setKey, client
}
from '../../../module/chatniosdk/client.js';
import {
    getQuota
}
from '../../../module/chatniosdk/api.js';
try{
setKey("sk-3ff89d0d143e8b4180ce5ae7863bc71d7a66918f69898bb3e0b4ee433786639e")
const messages = $('.messages')
let chat = new Chat(-1)
let chatInfor = true
alert('ggg')
btn('#send', () => {
    let v = $('textarea').value
    let t = ''
    if (chatInfor) {
        t = `Always use Chinese： 问题：${v}`
        chatInfor = false
    } else {
        t = `${v}`
    }
    messages.innerHTML += `                <div class="message sent"><div class="bubble">${t}</div></div><div class="message"><div class="bubble" id='gptreturn'> </div></div>`
    let gptreturn = $('#gptreturn')
    chat.askStream({
        message: t,
        model: 'azure-gpt-3.5-turbo-16k',
        type: 'chat'
    }, (res) => {
        //alert(JSON.stringify(res))

        gptreturn.innerHTML += res.message
        if(res.end){
        gptreturn.id=''
        }
    });
    $('textarea').value = ''
})
}catch(err){alert("error:"+err.stack)}
