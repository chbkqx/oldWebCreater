//初始化部分
//从本地存储中取回代码
try {
    wheelRun()
    var cache = {
        color: {
            data: {
                a: "#ffffff",
                b: "ff",
                re: "",
                elem: ""
            }
        }
    }
    var setdata = {
        doUse: {
            InteriorCSS: false,
            FastEdit: false
        },
        doWarning: {
            removeElement: true,
            removeDiv: true
        }
    }
    var CSSlist = {
        "&#58;root": {}
    }
    var color = {
        newcolor: {
            tag: "",
            data: ""
        }
    }
    var changeElementType = false;
    var preElement = document.querySelector(".previewElement *")
    var chooseElement = document.querySelector("#cho")
    var optionBox = document.querySelector("#optionBox")
    var previewElement = {
        object: document.querySelector(".previewElement *"),
        type: "p",
        textnode: true,
        attr: []
    }
    var list = 0
    var listtest = function() {
        list + 1
        return list
    }
    var costumeAttrList = ["www"]
    //保存代码(表单到本地)
    var r = document.querySelector(':root');

    
    //css颜色到表单
    /*function colorToForm(color) {
    var varlist = document.querySelector("#varlist")
    varlist.createNewElement("div","","c",(element)=>{element.id = })//写到这里
    varlist.createNewElement("p",color.tag+"()")
}*/


    //依据元素调整表单
    //快速编辑文本
    function elementToForm() {
        getElementType()
        //这里还需要一个函数，让小类的值等于元素的值
    }
    //根据元素大类型调整表单和小类标准，仅修改大类时调用
    function getElementType() {
        var allDivs = document.querySelectorAll("#exclusiveAttr>div");
        var i = 0
        var c_type_choose_v = document.querySelector('#c_type_choose')
            .value
        for (i = 0; i < allDivs.length; i++) {
            allDivs[i].style.display = "none";
        };
        previewElement.type = c_type_choose_v
        al("#exclusiveAttr>#" + c_type_choose_v)
        document.querySelector("#exclusiveAttr>#" + c_type_choose_v)
            .style.display = "block"
    }
    /*
表单数据规则(新版)
data-change-attr=(数据名)
*/
    function b(preElement, innerHTML) {

    }
    //修改预览元素(表单到预览)
    function modifyPreviewElement() {
        //如果改变了大类，则在此处调用函数
        if (changeElementType == true) {
            changeElementType = false
            getElementType()
            modifyPreviewElementType()
        }
    }

    /*
下面一个函数会在需要修改元素名称(重新创建新元素并继承数据)时调用，它需要完成以下任务：
0.调用getElementType(上2)获取元素类型
1.创建一个新元素，名称等于previewElement.type
2.让新元素替换旧元素
3.document.querySelector("#c_code")
        .value = preElementP.innerHTML;显示源代码
*/
    //需要修改类别时，包括大小类，传3个参，第一个是元素类型，第二个是新元素是否有文本子节点，第三个是回调函数，会传回新元素。
    function modifyPreviewElementType(callback) {
        var oldElement = document.querySelector(".previewElement>*")
        var para = document.createElement(previewElement.type);
        if (previewElement.textnode == true) {
            var node = document.createTextNode(oldElement.innerHTML)
            para.appendChild(node)
        }
        //把旧元素的属性给新元素
        var oldElementNodeMap = oldElement.attributes

        for (var qw of oldElementNodeMap) {
            para.setAttribute(qw.name, qw.value)
        }
        //替换元素
        oldElement.parentNode.replaceChild(para, oldElement)
        document.querySelector("#c_code")
            .value = document.querySelector(".previewElement")
            .innerHTML;
        //重置preElement元素为新元素
        preElement = document.querySelector(".previewElement *")
        //为新元素创建编辑属性和监听器
        if (previewElement.textnode == true) {

            preElement.setAttribute("contenteditable", "true");
            preElement.addEventListener("blur", function() {
                document.querySelector("#c_code")
                    .value = document.querySelector(".previewElement")
                    .innerHTML;
            })
        }
        //回调函数
        if (callback) {
            callback(preElement)
        }
    }
    //睡觉睡觉小激动计算机
    //预览到文件
    //创建新元素
    function createnew(n) {
        var newe = document.querySelector(".previewElement *")
            .cloneNode(true)
        //把data-contenteditable变成正常的contenteditable
        if (newe.getAttribute("data-contenteditable")) {
            newe.setAttribute("contenteditable", newe.getAttribute("data-contenteditable"));
        } else {
            newe.removeAttribute("contenteditable")
        }
        if (document.querySelector("#cho")) {
            if (n == "n") {
                document.querySelector("#cho")
                    .parentNode.appendChild(newe);
            } else {
                document.querySelector("#cho")
                    .appendChild(newe);
            }
        } else {
            document.querySelector("#previewPage")
                .appendChild(newe)
        }
        getPage()
        saveCode()
    }

    function createNewAttr() {
        var name = prompt("新属性名称")
        if (name === null) {
            alert("已取消")
        } else {
            costumeAttrList.push(name)
            localStorage.costumeAttrList = JSON.stringify(costumeAttrList)
            objectToForm(name, costumAttrDiv, function(b) {
                newElement(b)
                b.className = "shortText"
            })
        }
    }

    function hexadecimalProcessing(hex, callback) {
        var hexx = hex.toString('16')
        if (hex <= 15) {
            hexx = "0" + hexx
        }
        if (callback) {
            callback(hexx)
        }
    }

    function createNewColor() {
        CSSlist["&#58;root"]['--' + cache.color.data.c] = cache.color.data.re;
        jsonToCss(JSON.stringify(CSSlist), (css) => {
            document.querySelector("#cssCode")
                .value = css;
            coverPage()
        })
        localStorage.setItem("csslist", JSON.stringify(CSSlist))
        colorForm(cache.color.data.c, cache.color.data.re, document.querySelector("#varlist"))
    }

    function colorForm(jsonp, color, ele) {
        ele.createNewElement("div", "", "c", (elem) => {
            elem.createNewElement("p", "null", "c");
            cache.color.data.elem = elem
        })
        colorToElement(color, jsonp, cache.color.data.elem)
    }
    colorForm("shhdhxh", "#0000ff9b", document.querySelector("#varlist"))

    function colorFormToPreview() {
        //处理一位的数
        var oooo
        hexadecimalProcessing(cache.color.data.b, (wxwx) => {
            oooo = wxwx
        })
        cache.color.data.re = cache.color.data.a + oooo;
        var pvc = document.querySelector("#previewColor")
        colorToElement(cache.color.data.re, cache.color.data.c, pvc)
    }
    //把颜色代码转换成可显示的项目
    function colorToElement(color, name, element) {
        element.style.backgroundColor = color;
        element.firstChild.innerHTML = name + "(" + color + ")";
    }
    /*
css需要分成2种模式存储，一种是json，一种是css。
json随时保持可转化格式，通过调整CSSlist变量控制css
颜色不单独存储。
*/

    //新代码：修改元素(预览到文件)
    function modifyHTMLElement() {
        var chosenElement = document.querySelector("#cho");
        var preElementC = document.querySelector(".previewElement *")
            .cloneNode(true);
        chosenElement.parentNode.replaceChild(preElementC, chosenElement);
        preElementC.contentEditable = false;
        saveCode();
    }
    //文件到预览
    function chosenToPreview() {
        var chosenElement = document.querySelector("#cho");
        var preElement = document.querySelector(".previewElement *");
        preElement.parentNode.replaceChild(chosenElement.cloneNode(true), preElement);
        document.querySelector(".previewElement *")
            .className = ""
    }

    //预览到表单
    function PreviewToForm() {
        var preElement = document.querySelector(".previewElement *");
        document.querySelector('#c_type_choose')
            .value = preElement.nodeName.toLowerCase();
        document.querySelector('#c_word_choose')
            .value = preElement.innerHTML;
        document.querySelector('#c_href_choose')
            .value = preElement.href;
        elementToForm();
    }

    //切换页面
    /*function choiceThisElementX() {
    choiceThisElement(this, chosenTip);
    stopPropagation()
}

function chosenParent() {
    if (document.querySelector("#cho")
        .id == "previewPage") {
        alert("已经是最上层！")
    } else {
        var chosenElement = document.querySelector("#cho");
        chosenElement.parentNode.className = "chosen";
        chosenElement.className = ""
    }
};
*/
    function test() {
        var name = prompt("数组", costumeAttrList)
        if (name === null) {
            alert("已取消")
        } else if (name === "清空") {
            costumeAttrList = ["www"]
            localStorage.costumeAttrList = JSON.stringify(costumeAttrList)
        } else {
            costumeAttrList = name
            localStorage.costumeAttrList = JSON.stringify(costumeAttrList)
        }
    }

    function pageSet() {
        
    }

    /*function chosen(elem) {
    elem.addEventListener("click", function(e) {
        choiceThisElement(this, chosenTip);
        e.stopPropagation();
    }, false)
}*/

    function chosenTip(event) {
        var hov = document.querySelector("#cho")
        var box = document.querySelector("#choTipDivBox")
        hov.parentNode.insertBefore(box, hov);
        document.querySelector("#information")
            .innerHTML = "id:" + hov.id + " class:" + hov.className
        document.querySelector("#choTipDivBox")
            .style.display = "block"
        if (event.screenY < 180) {
            box.style.bottom = "-2em"
        } else {
            box.style.bottom = "110px"
        }
        event.stopPropagation();
    };

    /*以下函数把costumeAttrList数组转为实际可输入的列表
第一个值为预览对象
第二个值为位置(作为子元素加入)
第三个值为回调函数，传回新建的input。
*/
    function objectToForm(x, w, callback) {
        var cache = document.createElement("input")
        cache.type = "text"
        cache.placeholder = x
        cache.setAttribute("data-change-attr", "data-" + x)
        w.appendChild(cache)
        if (callback) {
            callback(cache)
        }
    }

    function Initialization() {
        AttrDiv = document.querySelector("#costumAttrDiv")
        for (let e of costumeAttrList) {
            objectToForm(e, costumAttrDiv, function(b) {
                newElement(b)
                b.className = "shortText"
            })
        }
        //解析css.json
        try {
            if (localStorage.csslist != undefined) {
                CSSlist = JSON.parse(localStorage.csslist)
                var CSSlistEleName = Object.getOwnPropertyNames(CSSlist["&#58;root"])
                var CSSlistArray = Object.values(CSSlist["&#58;root"])
                //alert(CSSlistArray)
                ergodic(CSSlistArray, (a, b) => {
                    colorForm(CSSlistEleName[b], CSSlistArray[b], document.querySelector("#varlist"))
                })
                for (m in CSSlist) {
                    //解析:root的变量部分
                    al(JSON.stringify(CSSlist["&#58;root"]))
                    colorForm(CSSlist["&#58;root"][m], cache.color.data.re, document.querySelector("#varlist"))
                }
            }
        } catch (err) {
            alert("cssListBug:" + localStorage.csslist + err.message)
        }
        //给选择器各个控件监听
        document.querySelector("#remove")
            .addEventListener("click", function(e) {
            var ch = document.querySelector("#cho")
            if (setdata.doWarning.removeElement == true) {
                var con = confirm("您确定要清除此元素吗？")
                if (con == false) {
                    e.stopPropagation();
                    return
                }
            }
            if (ch.tagName == "DIV" && setdata.doWarning.removeDiv == true) {
                var con = confirm("您确定要清除此块吗？这会清除块内的所有元素。")
                if (con == false) {
                    e.stopPropagation();
                    return
                }
            }
            document.querySelector("#choTipDivBox")
                .style.display = "none"
            ch.remove();
            e.stopPropagation();
        }, true)
        eleData("#textTypeSet", "data-pre-mode", "p")
        //给文字选项打后缀，需要.textType，不仅文字


        //给预览页面打监听器
        //特例：给内容编辑打上监听程序

        preElement.addEventListener("blur", function() {
            document.querySelector("#c_code")
                .value = document.querySelector(".previewElement")
                .innerHTML;
        })
        //导航程序，遍历导航文本并添加点击效果与切换页面功能

    }
    //window.addEventListener("click", function(e) {alert(e.screenX+" "+e.screenY+document.querySelector("p:hover"))},false)
    //开始初始化
    let pre = document.querySelector("#previewPageF")
    newSelectArea(pre, (element) => {
        
        if(element!=null){
        
        let rect = element.getBoundingClientRect();
        let x = rect.left;
        let y = rect.top;
        
        optionBox.style.top = y;
        optionBox.style.left = x;
        optionBox.style.display = "block";
        
        }else{
        optionBox.style.display = "none";
        }
    })
    getElementType()
    loadCode();
    coverPage();
    Initialization()
} catch (err) {
    alert("shitBug:"+err.message)
}
/*
以下内容为尚未完成内容
预览页面内边"距
css页面
新建更多内容
更多全局属性
全局属性继承
删除自定义属性
语言
*/