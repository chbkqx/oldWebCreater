import {
    c
}
from '../../module/jsd14c/core_min.js'
import "../../module/jsd14c/basic.js"
import "../../module/jsd14c/file.js"
import "../../module/jsd14c/input.js"
let js = {
    "format_version": 1,
    "list": {
        "global": {
            "onclick": new c.text('点击代码')
        }
    }
}
export {js}