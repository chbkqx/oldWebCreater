import {
    jsd, c, jsdType
}
from '../../module/jsd14c/core_min.js'
import "../../module/jsd14c/basic.js"
import "../../module/jsd14c/file.js"
import "../../module/jsd14c/input.js";
/*import {
    jsd, c, jsdType
}
from "..//core.js"*/
//


import {
    jq, $, btn
}
from "http://localhost:8080/module/wheel/jq.js"
import {css} from './css.js'
// index.js
try {
    //let a = new jdidwhhxjzjzjak()
    //alert('hshs')
    
    const aa = [new c.text("颜色"), new c.text("颜色")]
    /*这是一个使用示例，解析了一个wb类型的自定义项目，在生产环境中删掉它
printObjectProperties(q, d, divv, function(w, o){
    let ttt
    switch (w.type) {
        case "wb":
            ttt = divv.createNewElement("p", w.list)
            alert(JSON.stringify(w))
            break;
    }
});
*/

    //alert('婚纱徐'+aa.constructor)
    let d = {}

    d = jsd(css, document.querySelector("#di"), {
        omitDefaults: true,
        setCallback: (a, b, c, d) => {
            $('#text').innerHTML = `a: ${JSON.stringify(a).slice(0,50)},b:${b.slice(0,50)},c:${c.slice(0,50)},d:特殊: ${JSON.stringify(d[b]).slice(0,50)}`
        }
    })

    btn('#text', () => {
        var code = "";
        if (localStorage.code) {
            code = localStorage.code;
        }
        let proCode = prompt("请输入代码", code)
        let pro = "try{" + proCode + ";alert('命令执行成功')}catch(err){alert('命令错误：'+err.message)}";
        if (proCode) {
            eval(pro)
            localStorage.code = proCode;
        }
    })
    $('#bu')
        .on('click', () => {
        alert(JSON.stringify(d))
    })
    $('#see')
        .on('click', () => {
        alert(document.body.innerHTML)
    })
} catch (err) {
    alert("测试文件报错 error:" + err.stack)
}