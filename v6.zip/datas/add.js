import {
    $, btn
}
from "../../../module/wheel/jq.js"
async function fetchAddFile(file = 'add.json',element = $('#add')){
try{function a(d){
try{for(let i in d){
element.createNewElement('p',{'class':'infor',innerHTML:d[i].title})
for(let ii in d[i].data){
element.createNewElement('div',{data:{imgsrc:`element/${ii}`,nodename:ii,infor:d[i].data[ii]}})
}
}
}catch(err){alert("error:"+err.stack)}
}
let de = {}
if(typeof file == 'string'){
let x = await fetch(file)
let y = await x.json()
a(y)
return y
}
}catch(err){alert("error:"+err.stack)}
}
export {fetchAddFile}