import {
    c
}
from '../../module/jsonTemp/index.js'
//import "./jsd++.js"

let html 
try{
html = {
    "format_version": 1.0,
    "list": {
        "global": {
            id: new c.text('id'),
            innerHTML: new c.textarea('globalText(Not recommended)'),
            draggable: new c.boolean('拖动', false)
        },
        "text": {
            innerHTML: new c.textarea('文本内容'),
            nodeType: new c.select('文本类型', {
                "p": "段落",
                "b": "加粗",
                "pre": "预格式",
                "u": "下划线",
                "i": "斜体",
                "s": "已删除文本",
                "q": "短引用",
                "mark": "高亮标记",
                "abbr": "缩写",
                "address": "联系信息",
                "cite": "引用",
                "code": "计算机代码",
                "em": "强调",
                "strong": "更强的强调",
                "dfn": "定义项目",
                "var": "变量"
            })
        },
        "h": {
            nodeType: new c.sprit('', ['h', new c.number('标题大小', [1, 6, 1])])
        },
        href: {
            href: new c.text("链接指向")
        },
        progress: {
            value: new c.number('进度条已经走了的进度', [0, 100, 0]),
            max: 100
        },
        "title": {
            "title": new c.text("额外信息(title)")
        },
        "img": {
            src: new c.image("图片",{uploadPath: 'webCreater/v4n/cache/'}),
            loading: new c.select('加载方式', {
                eager: '立刻加载',
                lazy: '稍后加载'
            })
        },
        "media": {
            "preload": new c.boolean('预加载', false),
            innerHTML: new c.array("来源", [new c.sprit('', ['<source src="', new c.text('来源链接'), '" type="', new c.text('来源文件类型'), '">'])], [], {
                string: true
            })
        },
        audio: {
            "muted": new c.boolean('静音', false),
            "loop": new c.boolean('循环播放', false),
            "controls": new c.boolean('显示控件', true),
            "autoplay": new c.boolean('自动播放', false)
        },
        "input": {
            "accept": new c.text('上传文件类型'),
            "autocomplete": new c.select('是否保存上次提交内容', {
                'on': '是',
                off: '否'
            }),
            type: new c.select('表单类型', {
                'text': '一般文本',
                'password': '密码',
                'radio': '单选',
                'file': '上传文件',
                'checkbox': '多选',
                'number': '数字',
                'date': '日期',
                'color': '颜色',
                'range': '滑块',
                'email': '电子邮件(英文)',
                'search': '搜索框(自带x)',
                'tel': '手机号',
                'url': '链接(英文)'
            })
        }
    }
}
}catch(err){alert("HTML error:"+err.stack)}
//localStorage.setting.costumConfig.attrList
/*function getTempObj(n) {

    if (!elementFamilyList.list[n]) {
        let a = document.createElement(n)
        alert(`getTempObj.js错误：未定义的元素类型：${n}，调查数据：${a.constructor}`)
        elementFamilyList.list[n] = ["global",'text']
    }
    elementFamilyList.list[n].forEach((element, index, array) => {
        Object.assign(tempObj.html, attrList.list[element])
    })
    elementFamilyList.list[n].forEach((element, index, array) => {
        Object.assign(tempObj.css, cssList.list[element])
    })
    return tempObj
}
*/
export {
    html
}