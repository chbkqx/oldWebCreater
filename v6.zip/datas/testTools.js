function $(a){
return document.querySelector(a)
}
Element.prototype.on = function(event, callback) {
this.addEventListener(event, callback);
}
Element.prototype.createNewElement = function(nodeName, attrObject = {}, mode = "c") {
function setAllAttributes(element, attrObject) {
    for (let key in attrObject) {
        if(key=="innerHTML"){
        element.innerHTML = attrObject[key]
        }else if (attrObject[key]){
        //一般值，不是undefined
        if(typeof attrObject[key]=='object'){
        element.setAttribute(key,JSON.stringify(attrObject[key]))
        }else{
        element.setAttribute(key,attrObject[key])
        }
        }
    }
}
try{
    //alert('特殊')
    const element = document.createElement(nodeName);
    setAllAttributes(element,attrObject)
    switch (mode) {
        case "c":
            this.appendChild(element);
            break;
        case "a":
            this.parentNode.insertBefore(element, this.nextSibling);
            break;
        case "b":
            this.parentNode.insertBefore(element, this);
            break;
    }
    return element;
}catch(err){alert("wheel jq.js Element.prototype.createNewElement 错误:"+err.stack)}
};
let button = function(d, f) {
    let bd = document.querySelector('#buttonDiv')
    let nb = bd.createNewElement('button', {
        'type': 'button',
        innerHTML: d
    })
    nb.on('click', (e)=>{
    try{f(e)
}catch(err){alert(d+" button错误:"+err.stack)}
    })
}
window.input = ''
$('#input').on('input', () => {
    input = $('#input')
        .value
})
let output = (a)=>{
if(typeof a=='object'){
a=JSON.stringify(a)
}
$('#output').innerHTML = a
}
let log = (message)=>{
if(typeof message=='object'){
message=JSON.stringify(message)
}
$('#log').innerHTML += `${message}\n`
}
export {$,button,output,log}