import {
    c
}
from '../../module/jsd14c/core_min.js'
import "../../module/jsd14c/basic.js"
import "../../module/jsd14c/file.js"
import "../../module/jsd14c/input.js";

(() => {
    try {
        /*let o = new c.sprit('',[new c.number('', [a,b,c]),new c.radio('', {
                px: '像素',
                em: '相对于元素的字体大小',
                mm: '毫米',
                '%': '相对于父元素'
            }),' ']);
            alert(c.radio)
c.ss('length',(a = 0,b = 100,c = 0)=>{

return o
})*/
/*        c.ss('length', (name = '', a = 0, b = 64, s = false) => {
            //alert(c.radio+c.number)
            return new c.sprit(name, [new c.number('', [a, b, a],a,{transfinite:s}), new c.radio('', {
                px: '像素',
                em: '相对于元素的字体大小',
                mm: '毫米',
                '%': '相对于父元素'
            }), ' '],'',{className:'length'});
        })
        c.ss('blength', (name = '', a = 0, b = 1024, d = 0) => {
            //alert(c.radio+c.number)
            return new c.sprit(name, [new c.number('', [a, b, d]), new c.radio('', {
                px: '像素',
                em: '相对于元素的字体大小',
                mm: '毫米',
                '%': '相对于父元素'
            }), ' '],'',{className:'length'});
        })
        c.ss('fourLength', (a = '', b = '上(下)(所有)', d = '右(左)', f = '下', g = '左', l = 60) => {
            return new c.array(a, [c.s.length(b,0,l), c.s.length(d), c.s.length(f), c.s.length(g)], [], {
                joinwith: ' ',
                max: 4,
                className:'fourLength'
            })
        })
        c.ss('bFourLength', (a = '', b = '上(下)(所有)', d = '右(左)', f = '下', g = '左') => {
            return new c.array(a, [c.s.blength(b), c.s.blength(d), c.s.blength(f), c.s.blength(g)], [], {
                joinwith: ' ',
                max: 4,
                className:'fourLength'
            })
        })
        c.ss('border', (name) => {
            //alert(c.radio)
            return new c.sprit(name, [c.s.length(), new c.radio('', {
                solid: '实线',
                dashed: '虚线',
                dotted: '点线',
                double: '双层',
                groove: '凹槽',
                ridge: '垄状',
                inset: '3d凹下',
                outset: '3d凸起',
                none: '禁用边框'
            }), ' ', new c.color('')],'',{className:'border'})
        })*/
    } catch (err) {
        alert("error:" + err.stack)
    }
})();



let css = {
    "format_version": 1,
    "list": {
        "global": {
            'display': new c.optionlist('显示方式',{
            block:'块级',
            inline:'行内',
            'inline-block':'行内块',
            none:'不渲染',
            flex:'flex弹性布局',
            grid:'grid网格布局'
            }),
            'position': new c.optionlist('定位方式',{
            'static':'静态定位',
            relative:'相对于正常位置',
            absolute:'相对于最近的定位祖先元素',
            fixed:'相对于视窗',
            sticky:'粘性定位'
            }),
            'overflow':new c.optionlist('溢出内容处理',{
            'visible':'框外渲染',
            hidden:'隐藏',
            scroll:'添加滚动条',
            auto:'自动判断滚动条'
            }),
            'z-index':new c.number('高度(决定叠加效果)',[0,100,0,0.01]),
            opacity: new c.number('透明度',[0,1,1,0.01]),
            'border': c.s.border('边框全部'),
            'h': new c.command('details',`按照每个边设置边框`),
            "border-top": c.s.border('上'),
            "border-left": c.s.border('左'),
            "border-bottom": c.s.border('下'),
            "border-right": c.s.border('右'),
            outline: c.s.border('轮廓'),
            'outline-offset': c.s.length('轮廓偏移(轮廓距离边框多远)'),
            'hgdo': new c.command('detailsOver'),
            "border-radius": new c.array('圆角', [c.s.length('左上(右下)', 0, 20,true), c.s.length('左上(右下)', 0, 20,true), c.s.length('右下', 0, 20,true), c.s.length('左下', 0, 20,true)], [], {
                joinwith: '',
                max: 4
            }),
            "margin": c.s.bFourLength('外边距'),
            "padding": c.s.fourLength('内边距')
        },
        "text": {
            "color": new c.color('文本颜色'),
            "text-align": new c.optionlist('文本对齐方式',{left:'左对齐',center:'居中',right:'右对齐',justify:'拉伸'}),
            "hdhduw": c.command('details',`文本效果(一般建议修改html而不是使用css)`),
            'text-decoration':new c.optionlist('装饰',{none:'不使用',overline:'上方划线','line-through':'中间划线',underline:'下划线'}),
            'text-transform':new c.optionlist('文本转换',{none:'不使用',uppercase:'全大写',lowercase:'全小写',capitalize:'首字母大写'}),
            'hgdo': new c.command('detailsOver'),
            'text-indent':c.s.length('首行缩进'),
            'line-height': new c.number('行高',[0,10,0,0.1]),
            'word-spacing':c.s.length('字间距'),
            'white-space':new c.doubleRowRadio('空白与换行处理',{normal:'全部合并，自动划分',nowrap:'全部合并为一行',pre:'完整保留格式','pre-wrap':'保留换行，同时自动换行','pre-line':'保留换行，移除行末空格','break-spaces':'保留格式，空格转为换行'}),
            'font-size':c.s.length('文字大小'),
            'text-shadow':new c.color('影子')
        },
        input: {
            "caret-color": new c.color('光标颜色')
        },
        "background": {
            'background-color':new c.color('背景颜色'),
            'background-image':new c.sprit('',['url(',new c.BEimage('背景图像'),')'])
        },
        'flex':{
        'flex-direction':new c.doubleRowRadio('flex堆叠方向',{column:'从上到下',row:'从左到右','column-reverse':'从下到上','row-reverse':'从右到左'}),
        'flex-wrap':new c.doubleRowRadio('换行',{nowrap:'不换行',wrap:'允许换行','wrap-reverse':'反向换行'}),
        'justify-content':new c.doubleRowRadio('对齐方式',{nowrap:'不换行',wrap:'允许换行','wrap-reverse':'反向换行'})
        },
        grid:{}
    }
}
export {
    css
}