import {
    c
}
from '../../module/jsd14c/core_min.js'
import "../../module/jsd14c/basic.js"
import "../../module/jsd14c/file.js"
import "../../module/jsd14c/input.js"
let meta = {
    "format_version": 1,
    "list": {
        "global": {
            "author": new c.text('作者署名'),
            'scalable': new c.radio('',{yes:'允许用户缩放',no:'不允许用户缩放'}),
            'keywords':new c.text('关键词'),
            'description':new c.text('页面描述'),
            applicationName:new c.text('应用程序名称'),
            'referrer':new c.text('作者署名'),
            'title':new c.text('标题')
        }
    }
}
export {meta}