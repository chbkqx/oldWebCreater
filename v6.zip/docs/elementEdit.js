import {$,btn}from "../../../module/wheel/jq.js"
import {getTempObj} from "http://localhost:8080/webCreater/v4t/datas/getTempObj.js";
//import {jsd}from "../../../module/jsd14/core.js"
import {jsd}from "../../../module/jsd14c/core_min.js"

class editElement {
    constructor(form,htcallback,csscallback){
    this.form = form
    this.htmlSetCallback = htcallback
    this.cssSetCallback = csscallback
    }
    useJsd(tempObj,name){
    this[name] = jsd(tempObj,this.form,{setCallback:this[name+'SetCallback']})
    }
    gtempObj(name){
    //获取tempObj并重复调用useJsd设置属性
    let tempObj = getTempObj(name)
    this.useJsd(tempObj.html,'html')
    this.useJsd(tempObj.css,'css')
    }
    edit(element){
    let name = element.nodeName.toLowerCase()
    //清理form
    this.form.innerHTML = ''
    //交给tempObj分发
    this.gtempObj(name)
    }
}
class editElement2 {
    constructor(form,callback){
    this.form = form
    this.callback = callback
    }
    useJsd(tempObj,name){
    this.returnObj = jsd(tempObj,this.form,{setCallback:this.callback})
    }
    gtempObj(name,data){
    //获取tempObj并重复调用useJsd设置属性
    this.useJsd(data)
    }
    edit(element,data){
    let name = element.nodeName.toLowerCase()
    //清理form
    this.form.innerHTML = ''
    //交给tempObj分发
    this.gtempObj(data)
    }
    getData(name){
    //获取tempObj并重复调用useJsd设置属性
    let tempObj = getTempObj(name)
    this.useJsd(tempObj.html,'html')
    this.useJsd(tempObj.css,'css')
    }
}
/*let elementAttr
function elementEdit(element,callback){
const attrForm = $('#attrForm')
element.contenteditable = true;
let a = element.nodeName[0].toLowerCase()
let tempObj = getTempObj(a)
//alert(JSON.stringify(tempObj))
attrForm.innerHTML = ''
elementAttr = jsd(tempObj.html,attrForm,{setCallback:callback})
}*/
export{editElement,editElement2}