import {
    btn, setAllAttributes, $, getAllAttributes, downloadFile
}
from "../../../module/wheel/jq.js"
import {
    cho
}
from './selectArea.js'
import {
    wcPropertyMappings
}
from "./wcAttrFamily.js"
import {
    exportAllCSS, convertToCSSString
}
from './cssSync.js';
import {
    saveCode, loadCode
}
from './sync.js';
import {
    fs
}
from "/module/easyFile/new.js"


const baseHTML = [`<html><head>`, `</head>`, `</html>`]

//生成html内容的函数
function getHTML() {
    let {
        scalable, keywords, description, applicationName, referrer, author, title
    } = wcPropertyMappings.meta.returnObj
    let head = `<link rel="stylesheet" type="text/css" href="style/main.css"><meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=${scalable}" />
        <meta charset='utf-8' />
        <meta name='author' content='${author}'/>
        <meta name='keywords' content='${keywords}'/>
        <meta name='description' content='${description}'/><meta name='generator' content='jingyuanWebCreater'/><meta name='application-name' content='${applicationName}'/><meta name='referrer' content='${referrer}'/>
        <title>${title}</title>`
        let htc = localStorage.htmlcode.replaceAll('select-area','body');
    return `${baseHTML[0]}${head}${baseHTML[1]}${htc}${baseHTML[2]}`
}

function getCSS() {
    return convertToCSSString(exportAllCSS());
}

//文件层面
//导出html
btn('#exportHTML', () => {
    downloadFile(getHTML(), $('#down'))
})
btn('#exportCSS', () => {
    downloadFile(getCSS(), $('#down'))

})
btn('#closeProject', () => {
    if (confirm('关闭项目?你保存了吗？')) {
      //  htmlCode.innerHTML = ''
        localStorage.htmlcode = `<select-area id="htmlCode" data-multiple="true">
            <h1 id="hhhh">这是一个示例网页</h1>
            <div id="divdiv">
                一个框架 
                <p>一些正常的文字</p>
            </div> 
        </select-area>`
        localStorage.csscode = '{}'
        loadCode()
        window.localStorage.setItem('autoCSSCount', 0);
        
    }
})
btn('#saveProject', () => {
    fs.write('webCreater/v4t/project/cache/index.html', getHTML())
    fs.write('webCreater/v4t/project/cache/style/main.css', getCSS())
        .then(() => {
        alert(`数据已保存至webCreater/v4t/project/cache/目录`)
    })
})
btn('#previewProject', () => {
    window.open("project/cache/index.html", "_blank");
})
//设置层面
btn("#inputCode", () => {
    var code = "";
    if (localStorage.code) {
        code = localStorage.code;
    }
    let proCode = prompt("请输入代码", code)
    let pro = "try{" + proCode + ";alert('命令执行成功')}catch(err){alert('命令错误：'+err.stack)}";
    if (proCode) {
        eval(pro)
        localStorage.code = proCode;
    }
})
btn('#dhxjdkbdbcxksjsbx', () => {
    let outer = cho.outerHTML.selfArray
    let log = $('#log')
    log.innerText = ''
    for (let i of outer) {
        log.innerText += i
    }

})

//添加元素层，通过拖动添加元素
//初始化添加的元素(由于部分元素没有初始数据就无法显示无法长按无法编辑会死循环)
function createNewElementInit(name, newElementPosition) {
    try {
        function initNewElement(newElement) {
            newElement.dataset.byWC = true
            //初始化部分元素
            let a = newElement.nodeName.toLowerCase()
            //alert(a)
            switch (a) {
                case 'button':
                    newElement.innerHTML = '按钮'
                case 'img':
                    newElement.src = 'style/icons/example_img.png'
                    break;
                case 'iframe':
                    newElement.src = '/'
                    break;
                case 'audio':
                    newElement.controls = true;
                    let n = newElement.createNewElement('source')
                    n.src = 'style/resources/example.mp3'
                    n.type = "audio/mpeg"
                    break;
                case 'video':
                    newElement.controls = true;
                    let f = newElement.createNewElement('source')
                    f.src = 'style/resources/example.mp4'
                    f.type = "video/mp4"
                    break;
                default:
                    //newElement.innerHTML = '一个元素'
            }
        }
        //开始创建元素,做好错误处理
        let newElement = newElementPosition.createNewElement(name)
        initNewElement(newElement)
        //alert(newElement.outerHTML)
        //alert(newElement.parentNode.outerHTML)
        saveCode()
    } catch (err) {
        alert("editMenu.js #createNewElementButton error:" + err.stack)
    }
}

document.addEventListener("dragover", function(event) {
    event.preventDefault();
});
let htmlCode = $('#htmlCode')
htmlCode.on('drop', (event) => {
    try { //alert('ataya')
        event.preventDefault();
        event.stopPropagation()
        //alert(event.target.outerHTML)
        let a = event.dataTransfer.getData("Text")
        createNewElementInit(a, event.target)
        event.target.style.border = "";
    } catch (err) {
        alert("drop error:" + err.stack)
    }
})
htmlCode.on('dragenter', (event) => {
    event.stopPropagation()
    event.target.style.border = "3px dotted red";
})

htmlCode.on('dragleave', (event) => {
    event.stopPropagation()
    event.target.style.border = "";
})


export {
    createNewElementInit
}