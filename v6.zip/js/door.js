//import {}
export {proxyArray, file, DOMset, attrArray, $, btn, randomN, createDelay,log}from "../../../module/wheel/jqn.js"
export {state,store}from "../../../module/state/state.js"