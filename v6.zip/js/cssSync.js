function importCSS(importedCSS) {
    for (let selector in importedCSS) {
        let styles = importedCSS[selector];

        let styleElem = document.getElementById('cssCode');
        let sheet = styleElem.sheet;

        let ruleIdx = Array.from(sheet.cssRules).findIndex(rule => rule.selectorText === selector);

        if (ruleIdx === -1) {
            sheet.insertRule(`${selector} {}`, sheet.cssRules.length);
            ruleIdx = sheet.cssRules.length - 1;
        }

        for (let prop in styles) {
            sheet.cssRules[ruleIdx].style[prop] = styles[prop];
        }
    }
}

// 调用示例，假设之前导出的 CSS 存储在名为 importedCSS 的对象中
//importCSS(importedCSS);

function exportAllCSS() {
    let styleElem = document.getElementById('cssCode');
    let sheet = styleElem.sheet;
    let cssObj = {};

    for (let rule of sheet.cssRules) {
        let selector = rule.selectorText;
        let styles = {};

        for (let i = 0; i < rule.style.length; i++) {
            let prop = rule.style[i];
            styles[prop] = rule.style[prop];
        }

        cssObj[selector] = styles;
    }

    return cssObj;
}
function convertToCSSString(cssObj) {
    let cssString = '';
    for (let selector in cssObj) {
        cssString += `${selector} {\n`;
        for (let prop in cssObj[selector]) {
            cssString += `  ${prop}: ${cssObj[selector][prop]};\n`;
        }
        cssString += '}\n\n';
    }
    return cssString;
}

// 调用示例，假设之前导出的 CSS 存储在名为 exportedCSS 的对象中


// // 调用示例
// let exportedCSS = exportAllCSS();
// console.log(exportedCSS);
export {exportAllCSS,importCSS,convertToCSSString}