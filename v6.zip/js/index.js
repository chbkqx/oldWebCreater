//导入其他文件
//初始化jqn文件，现在所有文件里均可以使用它。
import "../../../module/wheel/jqn.js"
import {
    SVinit
}
from "../../../module/superView/index.js"
import {
    wModal, wOptionList, selectArea, wNav
}
from "../../../module/wheel/component.js";
import {
    makeDraggable, autoLoadMove
}
from "../../../module/wheel/move.js"
import './selectedElementMenu.js'

import {
    createNewElementInit
}
from './editMenu.js'
/*import {
    fetchAddFile
}
from "../datas/add.js";*/
import {
    runFunctionOnElementTouch
}
from "./xh.js"
import './ai.js'
//import {AttrFamily,PropertyMapping} from './edit.js'
/*import {
    loadCode
}
from './sync.js'*/
/*import {
    attrlist, attrForm
}
from './constList.js'
import {
    cho
}
from './selectArea.js'
import {
    editElement
}
from './editMenu.js'


import {
    $, btn
}
from "./attrListResolver.js"*/
/*import {loadCode} from './sync.js'
import {
    $, btn
}
from "./attrListResolver.js"*/
//import {selectArea} from './swe.js'
//import a from "./jxq.js";
//alert('轰炸书')
// 处理初始化选择错误   
//$('[data-cho]').removeAttribute('data-cho');

//渲染.cir内容，之后需要拆分

//let AttrFamily = new AttrFamily()
let addElement = $('.double-row>*:not(p)')
//wc私有代码
addElement.draggable = true
addElement.on("dragstart", (event) => {
    try {
        event.dataTransfer.setData("Text", event.target.dataset.nodename);
    } catch (err) {
        alert("error:" + err.stack)
    }
})
SVinit()
//老代码
try {
    //设置列表
    //alert('其他模块正常')
    /*document.body.addEventListener(
  'click',
  async (e) => {
    const text = await navigator.clipboard.readText();
    console.log(text);
  }
)*/
    /*document.querySelectorAll('w-nav>*').forEach(function (item) {
            item.style.height = item.scrollHeight + 'px';
        });*/

    //gnxan按钮(下方编辑菜单的开关能力)
    const editWindow = $('#editWindow')
    const nav = $('w-nav')
    btn('#editButton', function() {
        editWindow.open()
        //this.style.display = 'none';
    })
    
    //loadCode()
    autoLoadMove()

} catch (err) {
    alert("index.js error :" + err.stack)
}