import {$,btn,setAllAttributes}from "../../../module/wheel/jq.js"
import {jsdType,jsd,c}from "../../../module/jsd14c/core_min.js"
/*
jsdType.addmore('bigtext', function(returnObj, key, formDiv, value, worker) {
    let newValue = worker.getDv(key) || value.dv||""
    //alert(newValue)
    let newElement = formDiv.createNewElement("textarea", {
        "maxlength": value.list.maxlength,
        "placeholder": value.list.placeholder
    })
    newElement.on('input',()=>{
    returnObj[key] = newElement.value
    })
    newElement.value = newValue
})*/

jsdType.addmore('doubleRowRadio', function(returnObj, key, formDiv, value, worker) {
//alert(`被`)
    let newValue = worker.getDv(key) || value.dv||""
    //alert(newValue)
   // alert(`yhhh`)
    let newElement = formDiv.createNewElement("option-list")
    newElement.classList.add("double-row")
    //alert(`dgxhhzz`)
    for(let i in value.list){
    let a = newElement.createNewElement('div',{
    data:{
    infor:value.list[i],
    value:i
    },
    innerHTML:value.list[i]
    })
    a.style.backgroundImage = `linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,0.8),#f0f0f0),url(style/icons/element/${i}.png)`
    }
    newElement.on('change',()=>{
    returnObj[key] = newElement.dataset.value
    })
    returnObj[key] = ''
    newElement.refresh()
})

/*jsdType.addmore('border', function(returnObj, key, formDiv, value, worker) {
//alert(`被`)
    let newValue = worker.getDv(key) || value.dv||""
    //alert(newValue)
   // alert(`yhhh`)
    let newElement = formDiv.createNewElement("div")
    newElement.classList.add("jsdBorder")
    //alert(`dgxhhzz`)
    for(let i in value.list){
    let a = newElement.createNewElement('div',{
    data:{
    infor:value.list[i],
    value:i
    },
    innerHTML:value.list[i],
    })
    a.style.backgroundImage = `linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,0.8),#f0f0f0),url(style/icons/element/${i}.png)`
    }
    newElement.on('change',()=>{
    returnObj[key] = newElement.dataset.value
    })
    returnObj[key] = ''
    newElement.refresh()
})*/
jsdType.addmore('optionlist', function(returnObj, key, formDiv, value, worker) {
//alert(`被`)
    try{let newValue = worker.getDv(key) || value.dv||""
    //alert(newValue)
  //  alert(`yhhh`)
    let newElement = formDiv.createNewElement("option-list")
    let t = -1
    for(let i in value.list){
    
    let a = newElement.createNewElement('div',{
    data:{
    value:i
    },
    className:'icon'
    })
    t++
    //alert(`${t}`)
    
    a.style.background = `url(style/icons/element/${key}.png) ${-t*2}em 0`
    tippy(a,{content:value.list[i]})
    }
    newElement.on('change',()=>{
    returnObj[key] = newElement.dataset.value
    })
    returnObj[key] = ''
    newElement.refresh()
}catch(err){alert("error:"+err.stack)}
})