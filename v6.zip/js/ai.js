import {
    $, btn
}
from "../../../module/wheel/jq.js"
btn('#openai',a=>{
$('#openai').outerHTML ='<iframe id="ai" src="tools/gpt/" />'
})