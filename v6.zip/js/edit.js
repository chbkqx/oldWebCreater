import {
    $, btn
}
from "../../../module/wheel/jq.js"
import {
    jsd,jsdType
}
from "../../../module/jsd14c/core_min.js"
import "../../../module/jsd14c/basic.js"
import "../../../module/jsd14c/input.js"
import "../../../module/jsd14c/file.js"
import "../../../module/jsd14c/BEfile.js"
import "./jsd++.js"
import {log} from './door.js'
class PropertyMapping {
    constructor(AttrList, form, callback) {
        this.PropertyMap = []
        this.AttrList = AttrList.list
        this.version = AttrList.format_version
        this.form = form
        this.tempObj = {}
        this.returnObj = {}
        this.callback = callback
    }
    useJsd() {
        this.form.innerHTML = ''
        this.returnObj = jsd(this.tempObj, this.form, {
            setCallback: this.callback
        })
        //alert(`jsd刷新了`)
    }
    search(AttrFamily) {
        this.tempObj = {}
        //创建tempObj
        AttrFamily.forEach(e => {
            if (this.AttrList[e]) {
                Object.assign(this.tempObj, this.AttrList[e])
            }
        })
        //alert(JSON.stringify(this.tempObj))
        this.useJsd()
    }
}
class AttrFamily {
    constructor(AttrFamilyList, PropertyMap) {
        //单个类型属性的处理
        this.PropertyMap = PropertyMap || []
        //总AttrFamily
        this.AttrFamilyList = AttrFamilyList.list
        this.version = AttrFamilyList.format_version
    }
    //添加PropertyMapping
    addPropertyMap(PropertyMapping) {
        this.PropertyMap.push(PropertyMapping)
    }
    //获取
    get(element) {
        let AttrFamily = ['global']
        //1.遍历this.AttrFamilyList，判断该元素是否符合选择器，如果符合，拼接对象。
        for (let i in this.AttrFamilyList) {
        //alert(element.matches(i)+i+element)
            if (element.matches(i)) {
                AttrFamily.push(...this.AttrFamilyList[i])
            }
        }
        //此时，AttrFamily处理完成，开始分发给PropertyMapping
        log(JSON.stringify(AttrFamily))
        this.PropertyMap.forEach(e=>{
        e.search(AttrFamily)
        })
    }
    setPropertyMappingCallback(callback){
    this.PropertyMap.forEach(e=>{
    e.callback = callback
    })
    }
}
//alert(JSON.stringify(jsdType.get))
export {AttrFamily,PropertyMapping}