import {
    $, btn, setAllAttr
}
from "../../../module/wheel/jq.js"
import {
    cho
}
from "./selectArea.js"
import {
    wcAttrFamily
}
from "./wcAttrFamily.js"
import {
    autoCSS
}
from './autoCSS.js'
import {
    saveCode, loadCode
}
from './sync.js';
import {
    log, store, state
}
from './door.js'
import {
    SVinit
}
from "../../../module/superView/index.js"
let moveableElement

function makeMoveable(accordingElement) {
    moveableElement = new Moveable($('#htmlCode'), {
        "draggable": true,
        "scalable": false,
        "resizable": true,
        "roundable": true,
        "rotatable": true,
        "warpable": false,
        "pinchable": false,
        "groupable": false,
        "snappable": false,
        "clippable": false,
        "originDraggable": false,
        "selecto": false,
        "individualGroupable": false,
        "target": `[data-moveable]`
    })
    accordingElement.dataset.moveable = true
    //加上渲染系统
    moveableElement.on("render", e => {
        //alert(`gggg`)
        try {
            let ps = autoCSS.getCssPropSetter(autoCSS.lastSheetAndIdx, 'cssText')
            let[rules, idx] = autoCSS.lastSheetAndIdx;
            ps(merge([rules[idx].style.cssText, e.cssText]))
        } catch (err) {
            alert("error:" + err.stack)
        }
    })
    moveableElement.on("renderEnd", e => {
        try {
            let[rules, idx] = autoCSS.lastSheetAndIdx;
            log(merge([rules[idx].style.cssText, e.cssText]))
            saveCode()
        } catch (err) {
            alert("error:" + err.stack)
        }
    })
    let a = new store('moveableElement', moveableElement)
}
//合并css内容
function merge(strings) {
    var result = {}
    for (var i in strings) {
        var cssProperties = createObject(strings[i])
        for (var attr in cssProperties) {
            result[attr] = cssProperties[attr];
        }
    }
    var s = ''
    for (var attr in result) {
        s += attr + ':' + ' ' + result[attr] + '; ';
    }
    return s.trim()
}

function createObject(s1) {
    var obj = {};
    var properties = s1.split(';');
    for (var i = 0; i < properties.length; i++) {
        var property = properties[i].split(':');
        if (property.length == 2) {
            console.log(property[1]);
            obj[property[0].trim()] = property[1].trim();
        }
    }
    return obj;
}




btn('#remove', () => {
    cho.remove()
    saveCode()
})





btn('#edit', () => {
    try {
        //alert('xggx')
        let accordingElement = $('#htmlCode')
            .selectedElements[0]
        if (!accordingElement) {
            throw new Error(`错误:没有被选择的元素`)
        }
        //准备处理css内容
        autoCSS.prepareElements(cho.selfArray)
        //构建表单
        wcAttrFamily.get(accordingElement)
        //加入元素控制器
        if(accordingElement !== $('#htmlCode')){
        makeMoveable(accordingElement)
        }
        
        // SVinit()

    } catch (err) {
        alert("error:" + err.stack)
    }
})
btn('#copy', () => {
    cho.remove()
})




/*moveable.on("render", e => {
    e.target.style.cssText =  merge([e.target.style.cssText,e.cssText])
});

moveable.on("renderEnd", e => {
let o = e.datas
for(let i in o){
log(`key:${i} value:${o[i]}`)
}
  e.target.style.cssText =  merge([e.target.style.cssText,e.cssText])
    });
*/