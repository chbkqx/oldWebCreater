function runFunctionOnElementTouch(element, callback) {
    element.addEventListener('touchstart', handleTouchStart);
    element.addEventListener('touchend', handleTouchEnd);

    function handleTouchStart(event) {
        //event.preventDefault();
    }

    function handleTouchEnd(event) {
        const touch = event.changedTouches[0];
        const touchX = touch.clientX;
        const touchY = touch.clientY;

        const rect = element.getBoundingClientRect();
        const elementX = rect.left;
        const elementY = rect.top;
        const elementWidth = rect.width;
        const elementHeight = rect.height;

        if (
        touchX < elementX || touchX > elementX + elementWidth || touchY > elementY + elementHeight) {
            callback();
        }
    }
}

export{runFunctionOnElementTouch}