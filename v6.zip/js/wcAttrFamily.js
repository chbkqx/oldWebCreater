import {
    AttrFamily, PropertyMapping
}
from './edit.js'
import {
    $, attrArray, DOMset
}
from "../../../module/wheel/jqn.js"
import {
    saveCode
}
from './sync.js'
import {
    cho
}
from "./selectArea.js"
import {
    log
}
from './door.js'
import {
    autoCSS
}
from './autoCSS.js'
let wcAttrFamily = {};
let wcPropertyMappings = {};
function HTMLProcessor(t, p, v) {
    //处理nodeName情况
    switch (p) {
        case 'nodeType':
            for (let ii in cho.selfArray) {
                let r = DOMset.setNodeName(cho.selfArray[ii], v)
                htmlCode.select(r)
            }
            break;
        default:
            cho[p] = v
    }
    saveCode()
}


function CSSProcessor(t, p, v) {
    try {
        //如果本次写入的属性和上一次不一样，则重新调用autoCSS.getCssPropSetter以获取新的修改器
        if (p !== autoCSS.lastCSSProp) {
            log('hcj调用一次')
            autoCSS.lastCSSPropSetter = autoCSS.getCssPropSetter(autoCSS.lastSheetAndIdx, p)
        }
        //调用上一次的lastCSSPropSetter来修改对应属性。
        autoCSS.lastCSSPropSetter(v)
        //保存修改结果，之后可能会做一下粒度分类
        saveCode()
    } catch (err) {
        alert("CSSProcessor error:" + err.stack)
    }
}

async function fetchJson(link) {
    let html = await fetch(link)
    let html2 = await html.json()
    return html2
}

async function createPropertyMappingFromJson(h, c) {
    let html2 = await fetchJson(`./datas/${h}.json`)
    let htmlM = new PropertyMapping(html2, $(`#${h}Edit`), c)
    return htmlM
}

(async function editInit() {
    try{let attrFamily = await fetchJson('./datas/attrFamily.json')
    wcPropertyMappings.html = await createPropertyMappingFromJson('html',HTMLProcessor)
    wcPropertyMappings.css = await createPropertyMappingFromJson('css',CSSProcessor)
    wcPropertyMappings.js = await createPropertyMappingFromJson('js',log)
    wcPropertyMappings.meta = await createPropertyMappingFromJson('meta',()=>{})
    wcAttrFamily = new AttrFamily(attrFamily,[wcPropertyMappings.html,wcPropertyMappings.css,wcPropertyMappings.js,wcPropertyMappings.meta])
    //alert('wcwc')
}catch(err){alert("error:"+err.stack)}
})();

export {
    wcAttrFamily,wcPropertyMappings
}