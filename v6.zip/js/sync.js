import{importCSS,exportAllCSS} from './cssSync.js'
import {createDelay} from './door.js'
//同步代码
//保存代码(预览到本地)

function cleanString(str) {
    // 创建一个临时的HTML容器
    const tempDiv = document.createElement('div');
    // 将字符串解析为DOM并插入到临时容器中
    tempDiv.innerHTML = str;

    // 遍历所有子元素，查找并删除带有moveable-control-box类的元素及其内部内容
    Array.from(tempDiv.querySelectorAll('.moveable-control-box')).forEach(node => {
        node.remove();
    });
    //处理moveable data属性
    Array.from(tempDiv.querySelectorAll('[data-moveable]')).forEach(node => {
        delete node.dataset.moveable
    });

    // 将处理后的DOM结构转回字符串
    try{
    let cleanedString = tempDiv.innerHTML
    return cleanedString;
}catch(err){alert("error:"+err.stack)}
}


function nsaveCode() {
//alert(`保存`)
const htmlCode = document.querySelector("#htmlCode")
const cssCode = JSON.stringify(exportAllCSS())

    localStorage.htmlcode = cleanString(htmlCode.outerHTML)
    localStorage.csscode = cssCode
}
function saveCode() {
try{createDelay(nsaveCode,1500)
}catch(err){alert("error:"+err.stack)}
}
//加载代码(本地到表单)
function loadCode() {
//alert('dhdh')
try{
const htmlCode = document.querySelector("#htmlCode")
const cssCode = document.querySelector("#cssCode")
    htmlCode.outerHTML = localStorage.htmlcode||`<select-area id="htmlCode" data-multiple="true">
            <h1 id="hhhh">这是一个示例网页</h1>
            <div id="divdiv">
                一个框架 
                <p>一些正常的文字</p>
            </div> 
        </select-area>`;
    //alert(localStorage.csscode)
    importCSS(JSON.parse(localStorage.csscode||`{}`))
}catch(err){alert("error:"+err.stack)}
}
loadCode()
//覆盖网页(表单到预览)
export {saveCode,loadCode}