function tohex(hex) {
        let hexx = hex.toString('16')
        if (hex <= 15) {
            hexx = "0" + hexx
        }
        alert(hexx)
        return hexx
    }
function convertToNestedArray(str) {
    let result = [];
    let firstLevel = str.split(/,(?![^()]*\))/);

    firstLevel.forEach(element => {
        let secondLevel = element.trim().split(/\s(?![^()]*\))/);
        result.push(secondLevel);
    });

    return result;
}
function convertToString(arr) {
    let result = arr.map(function(item) {
        return item.join(" ");
    }).join(", ");
    return result;
}


/*
let str = "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)";
console.log(convertToNestedArray(str));


["0","4px","8px","0",{fname:'rgba',value:[0,0,0,0.2]}],["0","6px","20px","0",{fname:'rgba',value:[0,0,0,0.19]}]]*/


// 定义一个函数，将css字符串转换为js对象
function cssToJsObject(css) {
  // 创建一个空对象，用于存储转换后的属性和值
  let obj = {};
  // 去掉css字符串中的空格和分号
  css = css.replace(/\s+/g, "").replace(/;$/g, "");
  // 用分号分割css字符串，得到一个包含每个属性和值的数组
  let arr = css.split(";");
  // 遍历数组中的每个元素
  for (let i = 0; i < arr.length; i++) {
    // 用冒号分割每个元素，得到一个包含属性名和属性值的数组
    let pair = arr[i].split(":");
    // 将属性名转换为驼峰式，例如将background-color转换为backgroundColor
    let key = pair[0].replace(/-([a-z])/g, function(match, letter) {
      return letter.toUpperCase();
    });
    // 将属性名和属性值作为键值对添加到对象中
    obj[key] = pair[1];
  }
  // 返回转换后的对象
  return obj;
}

// 定义一个函数，将js对象转换为css字符串
function jsObjectToCss(obj) {
  // 创建一个空字符串，用于存储转换后的css字符串
  let css = "";
  // 遍历对象中的每个键值对
  for (let key in obj) {
    // 将属性名转换为短横线式，例如将backgroundColor转换为background-color
    let prop = key.replace(/([A-Z])/g, function(match, letter) {
      return "-" + letter.toLowerCase();
    });
    // 将属性名和属性值用冒号连接，并加上分号，添加到css字符串中
    css += prop + ":" + obj[key] + ";";
  }
  // 返回转换后的css字符串
  return css;
}

function readCss(style){
  let cssRules = style.sheet.cssRules
  let cssObject = {}
  for (let i in cssRules){
    // 使用style.sheet.cssRules[i].selectorText和style.sheet.cssRules[i].style.cssText
    //alert(cssRules[i].selectorText)
    if(cssRules[i].selectorText != undefined){
        cssObject[cssRules[i].selectorText] = {}
        for(let ii in cssRules[i].style){
        if(cssRules[i].style[ii] != ""){
        cssObject[cssRules[i].selectorText][ii] = cssRules[i].style[ii]
        }
        }
        
    }
  }
  alert(JSON.stringify(cssObject))
  return cssRules
}
function writeCss(style,element){
style.innerHTML = jsObjectToCss(element)
}
//readCss(cssCode)
export{tohex,cssToJsObject,jsObjectToCss,readCss,writeCss,convertToNestedArray,convertToString}

/*写一个js代码，传入一个形似0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);的字符串，将它转换为一个嵌套的数组，第一层数组以字符串中不在()里的,分割，第二层以空格分割，遇到rgba()这样的函数，将其转为{fname:rgba,value:[0, 0, 0, 0.19]}的形式*/