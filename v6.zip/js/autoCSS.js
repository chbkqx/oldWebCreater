import {
    log, createDelay
}
from './door.js'

let autoCSS = {
    autoCSSCount: window.localStorage.getItem('autoCSSCount') || 0,
    prepareElements: function(elements) {
        log('prepareElements调用一次');

        try {
            if (!Array.isArray(elements)) {
                elements = [elements];
            }

            let firstElementAutoCSS = elements[0].getAttribute('data-autoCSS');

            if (firstElementAutoCSS === null) {
                firstElementAutoCSS = 'autoCSS' + (++autoCSS.autoCSSCount);
                elements[0].setAttribute('data-autoCSS', firstElementAutoCSS);
                window.localStorage.setItem('autoCSSCount', autoCSS.autoCSSCount);
            }

            for (let i = 1; i < elements.length; i++) {
                let elementAutoCSS = elements[i].getAttribute('data-autoCSS');
                if (elementAutoCSS !== firstElementAutoCSS) {
                    elements[i].setAttribute('data-autoCSS', firstElementAutoCSS);
                }
            }

            let id = elements[0].getAttribute('data-autoCSS');
            let isNewID = elements.some(element => !element.getAttribute('data-autoCSS'));

            if (isNewID) {
                for (let element of elements) {
                    element.setAttribute('data-autoCSS', id);
                }
            }

            let styleElem = document.getElementById('cssCode');
            let sheet = styleElem.sheet;

            let ruleIdx = Array.from(sheet.cssRules)
                .findIndex(rule => rule.selectorText === `[data-autoCSS=${id}]`);

            if (ruleIdx === -1) {
                sheet.insertRule(`[data-autoCSS=${id}] {}`, sheet.cssRules.length);
                ruleIdx = sheet.cssRules.length - 1;
            }

            autoCSS.lastSheetAndIdx = [sheet.cssRules, ruleIdx];
            return [sheet.cssRules, ruleIdx];
        } catch (err) {
            alert("error:" + err.stack);
        }
    },
    getCssPropSetter: function(sheetAndIdx, cssProp) {
        //log('getcss调用一次')
        let[rules, idx] = sheetAndIdx;
        let{lastCSSProp, lastCSSPropSetter} = autoCSS
        rules[idx].style.willChange = cssProp
        log(rules[idx].style.willChange)
        createDelay(() => {
            rules[idx].style.willChange = ''
        }, 1000)
        let CSSPropSetter = (cssVal) => {
            // log('cssval调用一次')
            rules[idx].style[cssProp] = cssVal;
        }
        lastCSSProp = cssProp
        lastCSSPropSetter = CSSPropSetter
        return CSSPropSetter
    },
    lastSheetAndIdx: null,
    lastCSSProp: '',
    lastCSSPropSetter: null
}
export {
    autoCSS
}