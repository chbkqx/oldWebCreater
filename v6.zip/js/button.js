/*开始编辑按钮*/
import {
    $, btn
}
from "../../../module/wheel/jq.js"
try{let newElement
let newElementType
let newAttr = {}
/*function project(type, name, list) {
    this.type = type;
    this.name = name;
    this.list = list;
}
const attrlist = {
"all":{
"class":new project("text","类"),
"id":new project("text","ID")
//"lang":new project("lang","语言"),
},
"title":{
"title":new project("text","额外信息(title)")
}
}*/
//ael函数由于创建一个点击事件，简化操作，传入选择器和函数即可。
function ael(ele, fun) {
    return $(ele)
        .addEventListener('click', fun);
}

/*编辑功能框*/


//结构属性保存按钮


/*创建新元素相关*/
//打开form
ael("#add", (event) => {
    event.stopImmediatePropagation()
    $('#newElementForm')
        .open()
})
// 创建新元素按钮
ael('#createNewElementButton', () => {
    //创建变量表示新元素位置
    let newElementPosition
    //创建变量表示被选择元素
    let cho = $("[data-cho]")
    //确定是选择位置还是默认位置
    if (cho) {
        newElementPosition = cho
    } else {
        newElementPosition = htmlCode
    }
    //开始创建元素，做好错误处理
    if (boxlist.dataset.value) {
        newElementPosition
            .createNewElement(boxlist.dataset.value, {
            "data-attr": $('#boxlist > [data-choose="true"]')
                .dataset.attr
        })
    } else {
        alert('错误：元素未选择：' + boxlist.dataset.value)
    }
    saveCode()
})

function setPreviewColor() {
    previewColor.setColor($("#newColorInput")
        .value + hexadecimalProcessing(Number($("#newColorInput2")
        .value)), $("#newColorNameInput")
        .value)
}
$("#newColorInput")
    .on("change", (event) => {
    //设置颜色
    setPreviewColor()
})
$("#newColorInput2")
    .on("change", (event) => {
    //设置颜色
    setPreviewColor()
})
//设置颜色名
$("#newColorNameInput")
    .on("change", (event) => {
    setPreviewColor()
})
ael("#createNewColorButton", () => {
    colorList.appendChild(previewColor.cloneNode(true))
})

var navc = document.querySelector("#nav")
    .childNodes;
var navl = document.querySelector("#pages")
    .childNodes;
navc.forEach((n, i) => {
    if (n.nodeType == 1) {
        n.addEventListener("click", (k) => {
            navl.forEach((x) => {
                try {
                    x.style.display = "none";
                } catch (error) {}
            });
            navl[i].style.display = "block";
        });
    }
});

}catch(err){alert("error:"+err.message)}