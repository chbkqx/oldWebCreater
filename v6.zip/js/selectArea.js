import './sync.js'
import {
    $, btn,proxyArray
}
from "../../../module/wheel/jqn.js"
import {log,store,state} from './door.js'
import {
    saveCode, loadCode
}
from './sync.js';

let s = new store('moveableElement',{})
let cho = new proxyArray($('#htmlCode').selectedElements);
$('#htmlCode').selectEvent = ((e)=>{
$('#information').innerText = e.outerHTML
cho = new proxyArray($('#htmlCode').selectedElements);
})
$('#htmlCode').cancelEvent = ((e)=>{
cho = new proxyArray($('#htmlCode').selectedElements);
$('#information').innerText = ('已取消：'+e.outerHTML)
//清除moveable.js的调整框
if(e.dataset.moveable){
state.moveableElement.destroy()
delete e.dataset.moveable
}
saveCode()
})

//alert($('#htmlCode *[data-cho]',true))

//初始化选择所有cho
for(let i of $('#htmlCode *[data-cho]',true)){
//alert(`gxyx`)
try{let htmlCode = $('#htmlCode')
htmlCode.select(i)
log(i.outerHTML)
}catch(err){alert("error:"+err.stack)}
}



export {
    cho
}
//toJSON