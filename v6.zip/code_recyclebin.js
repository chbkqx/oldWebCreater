function TestButton(x) {
    var allpages = document.querySelectorAll(".page");
    var i = 0
    for (i = 0; i < allpages.length; i++) {
        allpages[i].style.display = "none";
    };
    allpages[x].style.display = "block";
    switch (x) {
        case 0:
            //网页预览页面
            //设置是否可快速编辑
            if (setdata.doUse.FastEdit == true) {
                document.querySelector("#previewPage")
                    .setAttribute("contenteditable", "true");
            } else {
                document.querySelector("#previewPage")
                    .setAttribute("contenteditable", "false");
            }
            break;
        case 1:
            var p_lister = document.querySelectorAll(".textType")
            var i;
            for (i = 0; i < p_lister.length; i++) {
                p_lister[i].addEventListener("click", function(e) {
                    previewElement.type = this.value;
                    e.stopPropagation();
                }, false)
            };
            //文本编辑页面
            break;
        case 4:
            //源代码编辑页面
            getPage();
            saveCode();

            break;
        case 3:
            al(document.body.innerHTML);
            al(document.querySelector(prompt("查询元素"))
                .innerHTML)
        default:
            break;
    }
};